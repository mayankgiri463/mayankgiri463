<div>
<h2 align='center'> <i>Hello, Folks! <img src="/icons/wave.gif" width="30px"> glad to see you here</i> 🙂</h2>

<img align="right" src="/icons/image.gif"  width="500">

_Hello there, this is **Abhishek Pal**. A **Full Stack Web Developer** with a vision to make this web beautiful. I spend my whole day, experimenting with HTML, CSS, and JavaScript; dabbling with React and Redux. I build websites that delight and inform. I do it well._
 </br>
</br>
- 🔭 I’m currently working on React.
- 🌱 Improving my DSA skills.
- 🤝 Pronouns: Abhi/He/Him
- 👯 I’m looking to collaborate with other devs on cool projects!
- 👨‍🎓 Ongoing Intern at Orions IT Solutions.
</div>
<div align="center">
</br>
</br>
<p align="center"><h3 align='center'><i>Social Media Handles</i></h3></p>
<p align='center'>
<a href="#"><img height="30" src="/icons/icons8-facebook-50.png"></a>&nbsp;&nbsp;
<a href="https://www.instagram.com/abhishekpal463"><img height="30" src="/icons/icons8-instagram-50.png"></a>&nbsp;&nbsp;
<a href="https://github.com/abhishekpal463"><img height="30" src="/icons/icons8-github-50.png"></a>&nbsp;&nbsp;
<a href="https://www.linkedin.com/in/abhishekpal463"><img height="30" src="/icons/icons8-linkedin-50.png"></a>&nbsp;&nbsp;
<a href="#"><img src="/icons/icons8-whatsapp-50.png"  height="30"></a>&nbsp;&nbsp;
</p>
<p align="center"><p> <img align="center" src="https://komarev.com/ghpvc/?username=abhishekpal463&color=blue" alt="counter"> </p></p>
</div>
<h2 align='center'><i><a href="https://github.com/abhishekpal463/github-readme-activity-graph">Activity Graph 📈</i></h2>
<p align="center">
<a href="https://github.com/abhishekpal463/github-readme-activity-graph">
 <img src="https://activity-graph.herokuapp.com/graph?username=abhishekpal463&theme=react-dark&area=true&hide_border=true" width="100%">
</a>
</p>
</br>
<h2 align='center'><i>💻⚙ Tech Stack & Tools ⚙💻</i></h2>

<table width="100">
<tr>
 <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/nodejs/nodejs-ar21.svg" width="120">
    </td>
 <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/expressjs/expressjs-ar21.svg" width="120">
    </td>
    <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/mongodb/mongodb-ar21.svg" width="120">
    </td>
    <td align='center' width="190">
        <img src="https://www.vectorlogo.zone/logos/reactjs/reactjs-ar21.svg" width="120">
    </td>
 <td align='center'>
        <img src="https://github.com/prplx/svg-logos/blob/master/svg/redux.svg" width="120">
    </td>
</tr>
<tr>
    <td align='center' width="190">
        <img src="https://github.com/devicons/devicon/blob/master/icons/cplusplus/cplusplus-original.svg" width="60">
    </td>
    <td align='center'>
        <img src="https://raw.githubusercontent.com/devicons/devicon/0d6c64dbbf311879f7d563bfc3ccf559f9ed111c/icons/css3/css3-original-wordmark.svg" width="60">
    </td>
    <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/w3_html5/w3_html5-ar21.svg" width="120">
    </td>
    <td align='center' width="190">
        <img src="https://github.com/abranhe/programming-languages-logos/blob/master/src/javascript/javascript.svg" width="60">
    </td>
    <td align='center' width="190">
        <img src="https://github.com/prplx/svg-logos/blob/master/svg/bootstrap.svg" width="60">
    </td>
    
</tr>
<tr>
    <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/firebase/firebase-ar21.svg" width="120">
    </td>
    <td align='center' width="190">
        <img src="https://github.com/gilbarbara/logos/blob/master/logos/netlify.svg" width="60">
    </td>
    <td align='center'>
        <img src="https://www.vectorlogo.zone/logos/heroku/heroku-ar21.svg" width="120">
    </td>
    <td align='center'>
        <img src="https://github.com/bestofjs/bestofjs-webui/blob/master/public/logos/vscode.svg" width="60">
    </td>
    <td align='center'>
        <img src="https://github.com/gilbarbara/logos/blob/master/logos/material-ui.svg" width="60">
    </td>
</tr>
</table>
<br >

## 🏆 Github Status
<div>
<img  src="https://github-readme-stats.vercel.app/api?username=abhishekpal463&show_icons=true&hide_border=true&theme=tokyonight" width="45%" align="right" >

<img  src="https://github-readme-streak-stats.herokuapp.com/?user=abhishekpal463&theme=tokyonight" width="45%" >
</div>
</br>
<div align="center">
<img  src="https://github-readme-stats.vercel.app/api/top-langs/?username=abhishekpal463&layout=compact&theme=tokyonight&langs_count=6&hide_border=true" width="45%" align="center" >
</div>
<br>
